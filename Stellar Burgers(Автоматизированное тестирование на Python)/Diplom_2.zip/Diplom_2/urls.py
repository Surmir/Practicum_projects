class Url():

    STELLAR_BURGER = 'https://stellarburgers.education-services.ru'
