"""
Перечисление с типами ингредиентов.
SAUCE – соус
FILLING – начинка
"""
INGREDIENT_TYPE_SAUCE = 'SAUCE'
INGREDIENT_TYPE_FILLING = 'FILLING'
