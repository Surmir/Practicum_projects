class Url():

    MAIN_PAGE = "https://stellarburgers.education-services.ru/"
    FEED_PAGE = f'{MAIN_PAGE}feed'
    LOGIN_PAGE = f'{MAIN_PAGE}login'
