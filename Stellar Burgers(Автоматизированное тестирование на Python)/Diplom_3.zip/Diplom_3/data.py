class UserLoginData():

    EMAIL = "greog@yandex.ru"
    PASSWORD = "576567rt"

class TestWaitTime():

    PAGE = 5
    WINDOW = 5
    VISIBLE = 5
    INVISIBLE = 5
    CLICKBLE = 5
