from pages.base_page import BasePage
from locators.base_page_locators import BasePageLocators as BPLocs
from locators.feed_page_locators import FeedPageLocators as FPLocs
from data import TestWaitTime as TWTime
from urls import Url
import allure


class FeedPage(BasePage):

    @allure.step('Открываем страницу "Лента Заказов"')
    def open_feed_page(self):
        self.go_to_page(Url.FEED_PAGE)

    @allure.step('Ожидание загрузки страницы "Лента Заказов"')
    def wait_load_feed_page(self, wait_time=TWTime.PAGE):
        self.wait_for_visibility_element(FPLocs.FEED_PAGE_HEADER, wait_time)

    @allure.step('Открываем главную страницу и ожидаем её загрузки')
    def wait_open_and_load_feed_page(self, wait_time=TWTime.PAGE):
        self.open_feed_page()
        self.wait_load_feed_page(wait_time)

    @allure.step('Нажимаем на кнопку "Конструктор" в шапке страницы')
    def click_button_builder(self):
        self.click_on_element(BPLocs.HEADER_BUTTON_BUILDER)

    @allure.step('Проверяем переход на главную страницу')
    def check_open_main_page(self):
        actual_url = self.get_page_url()
        expect_url = Url.MAIN_PAGE
        return actual_url == expect_url
    
    @allure.step('Проверяем счетчик «Выполнено за всё время»')
    def check_counter_completed_all_time(self):
        count = self.get_text(FPLocs.COUNTER_COMPLETED_ALL_TIME)
        return int(count)
    
    @allure.step('Проверяем счетчик «Выполнено за сегодня»')
    def check_counter_completed_today(self):
        count = self.get_text(FPLocs.COUNTER_COMPLETED_TODAY)
        return int(count)
    
    @allure.step('Проверяем раздел «В работе»')
    def check_section_in_work(self):
        text = self.get_text(FPLocs.SECTION_IN_WORK)
        return text[1:]
